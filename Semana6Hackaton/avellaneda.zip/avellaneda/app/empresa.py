class Empresa:
    def __init__(self, idempresa, rucEmpresa, nombreEmpresa):
        self.idempresa = idempresa
        self.rucEmpresa = rucEmpresa
        self.nombreEmpresa = nombreEmpresa
        