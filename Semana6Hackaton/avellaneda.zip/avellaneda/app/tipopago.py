class tipopago:
    def __init__(self, idtipoPago, descTipoPago):
        self.idtipoPago = idtipoPago
        self.descTipoPago = descTipoPago
        