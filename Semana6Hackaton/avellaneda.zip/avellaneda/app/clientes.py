class clientes:
    def __init__(self, idCliente, nombreCliente, numeroIdCliente, direccionCliente):
        self.idCliente = idCliente
        self.nombreCliente = nombreCliente
        self.numeroIdCliente = numeroIdCliente
        self.direccionCliente = direccionCliente
