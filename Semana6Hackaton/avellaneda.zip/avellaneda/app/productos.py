class Productos:
    def __init__(self, idproductos, nombreProducto, valorProducto, igvProducto):
        self.idproductos = idproductos
        self.nombreProducto = nombreProducto
        self.valorProducto = valorProducto
        self.igvProducto = igvProducto
