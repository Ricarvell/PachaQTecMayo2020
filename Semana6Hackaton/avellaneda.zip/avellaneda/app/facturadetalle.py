class facturaDetalle:
    def __init__(self, idfacDetalle, idfacCabecera, idproductos, cantFacDetalle, valorFacDetalle):
        self.idfacDetalle = idfacDetalle
        self.idfacCabecera = idfacCabecera
        self.idproductos = idproductos
        self.cantFacDetalle = cantFacDetalle
        self.valorFacDetalle = valorFacDetalle